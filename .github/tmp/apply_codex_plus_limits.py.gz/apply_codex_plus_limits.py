from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path.cwd()


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    if new in text:
        return
    if old not in text:
        raise SystemExit(f"anchor not found in {path}: {old[:100]!r}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def insert_before(path: Path, marker: str, block: str) -> None:
    text = path.read_text(encoding="utf-8")
    if block.strip() in text:
        return
    if marker not in text:
        raise SystemExit(f"marker not found in {path}: {marker!r}")
    path.write_text(text.replace(marker, block + marker, 1), encoding="utf-8")


def write_new(path: Path, content: str) -> None:
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return
    if path.exists():
        raise SystemExit(f"refusing to overwrite existing file: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


codex_runner = ROOT / "deploy/hermes-coders/codex_runner.py"
replace_once(
    codex_runner,
    "import hmac\nimport json\nimport os\nimport re\nimport signal\nimport subprocess\n",
    "import hmac\nimport json\nimport math\nimport os\nimport re\nimport selectors\nimport signal\nimport subprocess\n",
)
replace_once(
    codex_runner,
    "import tempfile\nimport threading\nimport uuid\n",
    "import tempfile\nimport threading\nimport time\nimport uuid\n",
)
insert_before(
    codex_runner,
    "\n\nclass RunStore:\n",
    r'''

def _bounded_number(
    value: object,
    *,
    minimum: float,
    maximum: float,
) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(result) or result < minimum or result > maximum:
        return None
    return result


def _normalize_codex_rate_window(value: object) -> dict[str, int | float | None] | None:
    if not isinstance(value, dict):
        return None
    used_percent = _bounded_number(
        value.get("usedPercent"),
        minimum=0,
        maximum=100,
    )
    duration = _bounded_number(
        value.get("windowDurationMins"),
        minimum=1,
        maximum=525_600,
    )
    if used_percent is None or duration is None:
        return None
    resets_at = _bounded_number(
        value.get("resetsAt"),
        minimum=1,
        maximum=32_503_680_000,
    )
    return {
        "used_percent": used_percent,
        "window_duration_mins": int(duration),
        "resets_at": int(resets_at) if resets_at is not None else None,
    }


def normalize_codex_subscription_rate_limits(
    account_result: object,
    rate_result: object,
) -> dict[str, Any]:
    if not isinstance(account_result, dict):
        raise RuntimeError("Codex вернул неизвестный формат аккаунта")
    account = account_result.get("account")
    if not isinstance(account, dict) or account.get("type") != "chatgpt":
        raise RuntimeError("Codex не авторизован через ChatGPT")
    plan_type = str(account.get("planType") or "unknown").strip().casefold()
    if not isinstance(rate_result, dict):
        raise RuntimeError("Codex вернул неизвестный формат лимитов")
    rate_limits = rate_result.get("rateLimits")
    if not isinstance(rate_limits, dict):
        raise RuntimeError("Codex не вернул лимиты подписки")
    primary = _normalize_codex_rate_window(rate_limits.get("primary"))
    secondary = _normalize_codex_rate_window(rate_limits.get("secondary"))
    if primary is None and secondary is None:
        raise RuntimeError("Codex не вернул окна лимитов подписки")
    reached = rate_limits.get("rateLimitReachedType")
    return {
        "plan_type": plan_type,
        "primary": primary,
        "secondary": secondary,
        "rate_limit_reached_type": reached if isinstance(reached, str) else None,
    }


def read_codex_subscription_rate_limits(
    codex_bin: str,
    codex_home: Path,
    *,
    timeout_seconds: int = 12,
) -> dict[str, Any]:
    if not (codex_home / "auth.json").is_file():
        raise RuntimeError("Codex не авторизован")
    process = subprocess.Popen(
        [codex_bin, "app-server", "--stdio"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        bufsize=1,
        env={**os.environ, "CODEX_HOME": str(codex_home)},
    )
    if process.stdin is None or process.stdout is None:
        process.kill()
        raise RuntimeError("Codex app-server не запустился")
    deadline = time.monotonic() + max(3, timeout_seconds)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)

    def send(payload: dict[str, Any]) -> None:
        process.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
        process.stdin.flush()

    def collect(expected_ids: set[int]) -> dict[int, object]:
        results: dict[int, object] = {}
        while expected_ids - set(results):
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not selector.select(remaining):
                raise RuntimeError("Codex app-server превысил время ожидания")
            line = process.stdout.readline()
            if not line:
                raise RuntimeError("Codex app-server завершился без ответа")
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(payload, dict) or payload.get("id") not in expected_ids:
                continue
            request_id = int(payload["id"])
            if payload.get("error") is not None:
                raise RuntimeError("Codex app-server отклонил запрос лимитов")
            results[request_id] = payload.get("result")
        return results

    try:
        send(
            {
                "method": "initialize",
                "id": 1,
                "params": {
                    "clientInfo": {
                        "name": "velvet_balance_probe",
                        "title": "Velvet Balance Probe",
                        "version": "1.0",
                    }
                },
            }
        )
        collect({1})
        send({"method": "initialized", "params": {}})
        send(
            {
                "method": "account/read",
                "id": 2,
                "params": {"refreshToken": False},
            }
        )
        send({"method": "account/rateLimits/read", "id": 3})
        results = collect({2, 3})
        return normalize_codex_subscription_rate_limits(results[2], results[3])
    except (OSError, ValueError) as error:
        raise RuntimeError("Codex app-server недоступен") from error
    finally:
        selector.close()
        try:
            process.stdin.close()
        except OSError:
            pass
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)

''',
)
replace_once(
    codex_runner,
    "    def submit(self, payload: dict[str, Any]) -> dict[str, Any]:\n",
    "    def rate_limits(self) -> dict[str, Any]:\n"
    "        return read_codex_subscription_rate_limits(\n"
    "            self.codex_bin,\n"
    "            self.codex_home,\n"
    "        )\n\n"
    "    def submit(self, payload: dict[str, Any]) -> dict[str, Any]:\n",
)
replace_once(
    codex_runner,
    '        if self.command == "GET" and path == "/v1/capabilities":\n'
    '            self._json(HTTPStatus.OK, self.manager.capabilities())\n'
    '            return\n',
    '        if self.command == "GET" and path == "/v1/capabilities":\n'
    '            self._json(HTTPStatus.OK, self.manager.capabilities())\n'
    '            return\n'
    '        if self.command == "GET" and path == "/v1/rate-limits":\n'
    '            self._json(HTTPStatus.OK, self.manager.rate_limits())\n'
    '            return\n',
)

router = ROOT / "deploy/hermes-operator/coder_router.py"
replace_once(
    router,
    "    def submit(self, project: str, payload: dict[str, Any]) -> dict[str, Any]:\n",
    "    def rate_limits(self, project: str) -> dict[str, Any]:\n"
    "        return self.upstream(self._target(project), \"GET\", \"/v1/rate-limits\")\n\n"
    "    def submit(self, project: str, payload: dict[str, Any]) -> dict[str, Any]:\n",
)
replace_once(
    router,
    '            if len(parts) == 4 and parts[:2] == ["v1", "coders"] and parts[3] == "capabilities":\n'
    '                self._json(HTTPStatus.OK, self.router.capabilities(parts[2]))\n'
    '                return\n',
    '            if len(parts) == 4 and parts[:2] == ["v1", "coders"] and parts[3] == "capabilities":\n'
    '                self._json(HTTPStatus.OK, self.router.capabilities(parts[2]))\n'
    '                return\n'
    '            if len(parts) == 4 and parts[:2] == ["v1", "coders"] and parts[3] == "rate-limits":\n'
    '                self._json(HTTPStatus.OK, self.router.rate_limits(parts[2]))\n'
    '                return\n',
)

installer = ROOT / "deploy/hermes-orchestration/install.sh"
replace_once(
    installer,
    "def set_value(path: Path, name: str, value: str) -> None:\n"
    "    values = parse_env(path)\n"
    "    values[name] = value\n"
    "    path.write_text(\n"
    "        \"\\n\".join(f\"{key}={item}\" for key, item in values.items()) + \"\\n\",\n"
    "        encoding=\"utf-8\",\n"
    "    )\n"
    "    os.chmod(path, 0o600)\n",
    "def set_value(path: Path, name: str, value: str) -> None:\n"
    "    values = parse_env(path)\n"
    "    values[name] = value\n"
    "    path.write_text(\n"
    "        \"\\n\".join(f\"{key}={item}\" for key, item in values.items()) + \"\\n\",\n"
    "        encoding=\"utf-8\",\n"
    "    )\n"
    "    os.chmod(path, 0o600)\n\n\n"
    "def set_value_preserving(path: Path, name: str, value: str) -> None:\n"
    "    lines = path.read_text(encoding=\"utf-8\").splitlines()\n"
    "    output: list[str] = []\n"
    "    replaced = False\n"
    "    for raw in lines:\n"
    "        stripped = raw.strip()\n"
    "        key = stripped.split(\"=\", 1)[0].removeprefix(\"export \").strip() if \"=\" in stripped else \"\"\n"
    "        if key == name:\n"
    "            output.append(f\"{name}={value}\")\n"
    "            replaced = True\n"
    "        else:\n"
    "            output.append(raw)\n"
    "    if not replaced:\n"
    "        if output and output[-1].strip():\n"
    "            output.append(\"\")\n"
    "        output.append(f\"{name}={value}\")\n"
    "    path.write_text(\"\\n\".join(output).rstrip() + \"\\n\", encoding=\"utf-8\")\n"
    "    os.chmod(path, 0o600)\n",
)
replace_once(
    installer,
    'set_value(velvet_path, "HERMES_CODER_ROUTER_CLIENT_TOKEN", client_token)\n'
    'set_value(max_path, "HERMES_CODER_ROUTER_CLIENT_TOKEN", client_token)\n',
    'set_value(velvet_path, "HERMES_CODER_ROUTER_CLIENT_TOKEN", client_token)\n'
    'set_value(max_path, "HERMES_CODER_ROUTER_CLIENT_TOKEN", client_token)\n'
    'set_value_preserving(server_path, "CODEX_LIMITS_BASE_URL", "http://hermes-coder-router:8878")\n'
    'set_value_preserving(server_path, "CODEX_LIMITS_API_KEY", client_token)\n',
)

env_example = ROOT / ".env.server.example"
replace_once(
    env_example,
    "HERMES_MAX_LOG_CHARS=12000\n\nCODEX_COMMAND=",
    "HERMES_MAX_LOG_CHARS=12000\n\n"
    "# Read-only Codex ChatGPT subscription limits through the internal coder router.\n"
    "CODEX_LIMITS_BASE_URL=http://hermes-coder-router:8878\n"
    "CODEX_LIMITS_API_KEY=replace_with_same_value_as_HERMES_OPS_CLIENT_TOKEN\n\n"
    "CODEX_COMMAND=",
)

balances = ROOT / "velvet_bot/presentation/telegram/routers/workspace_auf_provider_balances.py"
replace_once(
    balances,
    "from dataclasses import dataclass\nfrom decimal import Decimal, InvalidOperation\n",
    "from dataclasses import dataclass\nfrom datetime import datetime, timezone\nfrom decimal import Decimal, InvalidOperation\n",
)
replace_once(
    balances,
    "_BYESU_BILLING_URL = \"https://byesu.com/dashboard/billing/subscription\"\n",
    "_BYESU_BILLING_URL = \"https://byesu.com/dashboard/billing/subscription\"\n"
    "_CODEX_LIMITS_DEFAULT_BASE_URL = \"http://hermes-coder-router:8878\"\n",
)
insert_before(
    balances,
    "\n\ndef _decimal(value: object) -> Decimal | None:\n",
    r'''

@dataclass(frozen=True, slots=True)
class CodexLimitWindow:
    used_percent: Decimal
    window_duration_mins: int
    resets_at: int | None


@dataclass(frozen=True, slots=True)
class CodexSubscriptionLimits:
    plan_type: str
    windows: tuple[CodexLimitWindow, ...]
    error: str | None = None
''',
)
insert_before(
    balances,
    "\n\nasync def _fetch_kie_balances(\n",
    r'''

def _read_codex_limits_json(
    *,
    base_url: str,
    api_key: str,
    timeout_seconds: int,
) -> Mapping[str, object]:
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/v1/coders/velvet/rate-limits",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
            "User-Agent": "VelvetBot/1.0 codex-limits",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        if error.code in {401, 403}:
            message = "доступ к лимитам Codex запрещён"
        else:
            message = f"Codex router вернул HTTP {error.code}"
        raise RuntimeError(message) from error
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        raise RuntimeError("Codex router недоступен") from error
    except json.JSONDecodeError as error:
        raise RuntimeError("Codex вернул неизвестный формат лимитов") from error
    if not isinstance(payload, Mapping):
        raise RuntimeError("Codex вернул неизвестный формат лимитов")
    return payload


def _codex_window(value: object) -> CodexLimitWindow | None:
    if not isinstance(value, Mapping):
        return None
    used = _decimal(value.get("used_percent"))
    duration = value.get("window_duration_mins")
    reset = value.get("resets_at")
    if used is None or used > 100 or isinstance(duration, bool) or not isinstance(duration, int):
        return None
    if duration <= 0 or duration > 525_600:
        return None
    resets_at = reset if isinstance(reset, int) and not isinstance(reset, bool) and reset > 0 else None
    return CodexLimitWindow(used, duration, resets_at)


async def _fetch_codex_subscription_limits() -> CodexSubscriptionLimits:
    api_key = os.getenv("CODEX_LIMITS_API_KEY", "").strip()
    base_url = os.getenv(
        "CODEX_LIMITS_BASE_URL",
        _CODEX_LIMITS_DEFAULT_BASE_URL,
    ).strip()
    if not api_key or not base_url:
        return CodexSubscriptionLimits("unknown", (), "интеграция не настроена")
    try:
        payload = await asyncio.wait_for(
            asyncio.to_thread(
                _read_codex_limits_json,
                base_url=base_url,
                api_key=api_key,
                timeout_seconds=_PROVIDER_TIMEOUT_SECONDS,
            ),
            timeout=_PROVIDER_TIMEOUT_SECONDS + 1,
        )
    except TimeoutError:
        return CodexSubscriptionLimits("unknown", (), "запрос лимитов превысил время ожидания")
    except RuntimeError as error:
        return CodexSubscriptionLimits("unknown", (), str(error))
    plan_type = str(payload.get("plan_type") or "unknown").strip().casefold()
    windows = tuple(
        window
        for window in (
            _codex_window(payload.get("primary")),
            _codex_window(payload.get("secondary")),
        )
        if window is not None
    )
    if not windows:
        return CodexSubscriptionLimits(plan_type, (), "окна лимитов не возвращены")
    return CodexSubscriptionLimits(
        plan_type,
        tuple(sorted(windows, key=lambda item: item.window_duration_mins)),
    )


def _codex_plan_label(plan_type: str) -> str:
    return {
        "plus": "Plus",
        "pro": "Pro",
        "team": "Team",
        "business": "Business",
        "enterprise": "Enterprise",
    }.get(plan_type, "ChatGPT")


def _codex_window_label(minutes: int) -> str:
    if minutes % 10_080 == 0:
        days = minutes // 1_440
        return f"{days} дн."
    if minutes % 60 == 0:
        return f"{minutes // 60} ч"
    return f"{minutes} мин"


def _codex_reset_label(
    resets_at: int | None,
    *,
    now: datetime | None = None,
) -> str | None:
    if resets_at is None:
        return None
    current = now or datetime.now(timezone.utc)
    seconds = max(0, int(datetime.fromtimestamp(resets_at, timezone.utc).timestamp() - current.timestamp()))
    minutes = (seconds + 59) // 60
    days, minute_remainder = divmod(minutes, 1_440)
    hours, minute_remainder = divmod(minute_remainder, 60)
    if days:
        return f"сброс через {days} д {hours} ч"
    if hours:
        return f"сброс через {hours} ч {minute_remainder} мин"
    return f"сброс через {minute_remainder} мин"


def _codex_lines(
    limits: CodexSubscriptionLimits,
    *,
    now: datetime | None = None,
) -> list[str]:
    plan = _codex_plan_label(limits.plan_type)
    if limits.error:
        return [f"• <b>Codex {escape(plan)}</b>: {escape(limits.error)}"]
    result: list[str] = []
    for window in limits.windows:
        remaining = max(Decimal("0"), Decimal("100") - window.used_percent)
        reset = _codex_reset_label(window.resets_at, now=now)
        suffix = f" · {escape(reset)}" if reset else ""
        result.append(
            f"• <b>Codex {escape(plan)} · {_codex_window_label(window.window_duration_mins)}</b>: "
            f"<b>{_format_decimal(remaining)}% осталось</b>{suffix}"
        )
    return result

''',
)
replace_once(
    balances,
    "    (kie_balance, grs_balance), byesu_balance = await asyncio.gather(\n"
    "        _fetch_kie_balances(kie_settings),\n"
    "        _fetch_byesu_balance(),\n"
    "    )\n",
    "    (kie_balance, grs_balance), byesu_balance, codex_limits = await asyncio.gather(\n"
    "        _fetch_kie_balances(kie_settings),\n"
    "        _fetch_byesu_balance(),\n"
    "        _fetch_codex_subscription_limits(),\n"
    "    )\n",
)
replace_once(
    balances,
    '            _provider_line("Byesu · остаток квоты ключа", byesu_balance),\n'
    '            "",\n',
    '            _provider_line("Byesu · остаток квоты ключа", byesu_balance),\n'
    '            *_codex_lines(codex_limits),\n'
    '            "",\n',
)

write_new(
    ROOT / "tests/test_codex_subscription_rate_limits.py",
    r'''from __future__ import annotations

import asyncio
import importlib.util
import os
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from velvet_bot.presentation.telegram.routers.workspace_auf_provider_balances import (
    CodexSubscriptionLimits,
    _codex_lines,
    _fetch_codex_subscription_limits,
)

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class CodexSubscriptionRateLimitTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.runner = load_module(
            "codex_runner_rate_limit_test_module",
            ROOT / "deploy/hermes-coders/codex_runner.py",
        )
        cls.router_source = (
            ROOT / "deploy/hermes-operator/coder_router.py"
        ).read_text(encoding="utf-8")

    def test_runner_normalizes_plus_windows_without_identity(self) -> None:
        payload = self.runner.normalize_codex_subscription_rate_limits(
            {
                "account": {
                    "type": "chatgpt",
                    "email": "hidden@example.com",
                    "planType": "plus",
                }
            },
            {
                "rateLimits": {
                    "primary": {
                        "usedPercent": 27,
                        "windowDurationMins": 300,
                        "resetsAt": 1_800_000_000,
                    },
                    "secondary": {
                        "usedPercent": 61.5,
                        "windowDurationMins": 10_080,
                        "resetsAt": 1_800_500_000,
                    },
                    "rateLimitReachedType": None,
                }
            },
        )

        self.assertEqual("plus", payload["plan_type"])
        self.assertEqual(27.0, payload["primary"]["used_percent"])
        self.assertEqual(10_080, payload["secondary"]["window_duration_mins"])
        self.assertNotIn("account", payload)
        self.assertNotIn("email", repr(payload))

    def test_router_exposes_only_read_only_rate_limit_proxy(self) -> None:
        self.assertIn(
            'return self.upstream(self._target(project), "GET", "/v1/rate-limits")',
            self.router_source,
        )
        self.assertIn('parts[3] == "rate-limits"', self.router_source)

    def test_bot_formats_remaining_plus_limits(self) -> None:
        payload = {
            "plan_type": "plus",
            "primary": {
                "used_percent": 27,
                "window_duration_mins": 300,
                "resets_at": 1_800_000_000,
            },
            "secondary": {
                "used_percent": 61.5,
                "window_duration_mins": 10_080,
                "resets_at": 1_800_500_000,
            },
        }
        with (
            patch.dict(
                os.environ,
                {
                    "CODEX_LIMITS_BASE_URL": "http://hermes-coder-router:8878",
                    "CODEX_LIMITS_API_KEY": "router-secret-not-printed",
                },
                clear=True,
            ),
            patch(
                "velvet_bot.presentation.telegram.routers."
                "workspace_auf_provider_balances._read_codex_limits_json",
                return_value=payload,
            ),
        ):
            limits = asyncio.run(_fetch_codex_subscription_limits())

        lines = _codex_lines(
            limits,
            now=datetime.fromtimestamp(1_799_990_000, timezone.utc),
        )
        self.assertEqual(2, len(lines))
        self.assertIn("Codex Plus · 5 ч", lines[0])
        self.assertIn("73% осталось", lines[0])
        self.assertIn("Codex Plus · 7 дн.", lines[1])
        self.assertIn("38.5% осталось", lines[1])
        self.assertNotIn("router-secret", "\n".join(lines))

    def test_bot_reports_missing_integration_safely(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            limits = asyncio.run(_fetch_codex_subscription_limits())
        self.assertIsInstance(limits, CodexSubscriptionLimits)
        self.assertEqual("интеграция не настроена", limits.error)


if __name__ == "__main__":
    unittest.main()
''',
)

write_new(
    ROOT / "docs/worklog/2026-08-05-codex-plus-rate-limits.md",
    r'''# Сессия

- Дата: 2026-08-05
- ID: `codex-plus-rate-limits-20260805`
- Статус: `завершено`
- Ветка: `feat-codex-plus-rate-limits`
- Базовый commit: `cc22b85068127327cda87ca7315a5470d0e76b9c`
- Линия/фаза: `owner provider balances / Codex subscription observability`

## Перед началом

### Цель

Добавить на служебный экран балансов лимиты Codex, относящиеся к действующей ChatGPT-подписке coder-профиля Velvet, с остатком по каждому возвращённому окну и временем до сброса.

### Исходный контекст

Coder Velvet уже авторизован в Codex через ChatGPT OAuth и хранит `auth.json` только внутри защищённого `/srv/hermes-coders/codex/velvet`. Codex app-server предоставляет стабильные read-only методы `account/read` и `account/rateLimits/read`. Бот не должен получать OAuth-файл, email аккаунта, refresh token или сырой ответ app-server.

Между production-сетью Velvet и изолированной coder-сетью уже существует аутентифицированный `hermes-coder-router`, подключённый к обеим сетям. Поэтому лимиты можно передавать через узкий read-only endpoint без расширения доступа bot-контейнера.

### Планируемый объём

- получить plan type и окна лимитов через локальный Codex app-server;
- нормализовать только проценты использования, длительность окна и Unix-время сброса;
- добавить read-only endpoint coder runner и прокси-маршрут router;
- передать существующий router client token в `.env.server` через orchestration installer;
- показать в Telegram процент остатка и относительное время до сброса;
- добавить regression-тесты нормализации, маршрута, форматирования и отсутствующей конфигурации.

### Вне объёма

- чтение общего ChatGPT billing или API billing;
- передача OAuth-файлов в bot-контейнер;
- расходование earned reset credits;
- отображение email, account id, access token или refresh token;
- ручное назначение лимитов, отсутствующих в ответе Codex.

### Критерии готовности

- plan `plus` отображается как `Codex Plus`;
- окно 300 минут отображается как `5 ч`, 10080 минут как `7 дн.`;
- `usedPercent=27` отображается как `73% осталось`;
- reset time отображается относительным безопасным текстом;
- Telegram и router не выводят идентификаторы аккаунта и секреты;
- все обязательные CI-проверки проходят.

### Риски и ограничения

- backend может вернуть только одно окно, поэтому UI отображает только фактически полученные окна;
- запуск app-server добавляет несколько секунд к ручному обновлению служебного экрана;
- Codex CLI и runner release должны обновляться совместно;
- production требует повторного orchestration install/reconcile для передачи endpoint и токена в `.env.server`.

## После завершения

### Фактически сделано

- runner выполняет обязательный initialize/initialized handshake Codex app-server;
- account и rate-limit ответы сокращаются до безопасного DTO без email и токенов;
- добавлен аутентифицированный `GET /v1/rate-limits` и router proxy для проекта Velvet;
- orchestration installer сохраняет router endpoint и существующий client token в `.env.server`;
- служебный экран показывает каждое доступное окно подписки, процент остатка и время до сброса;
- добавлены focused regression-тесты.

### Миграции и совместимость

Миграций базы данных нет. Новые переменные `CODEX_LIMITS_BASE_URL` и `CODEX_LIMITS_API_KEY` записываются installer-ом без раскрытия значения. При отсутствии переменных экран деградирует в безопасное сообщение `интеграция не настроена`.

### Проверки

- Python sources компилируются;
- focused unit-тесты покрывают Plus, два окна, безопасное DTO и отсутствующую конфигурацию;
- package architecture inventory регенерирован штатным скриптом;
- обязательные CI-проверки запускаются на PR.

### Решения и компромиссы

- используется официальный app-server, а не частные ChatGPT backend endpoints;
- бот обращается к coder runner только через существующий аутентифицированный router;
- email и прочие account fields отбрасываются на стороне runner;
- остаток вычисляется как `100 - usedPercent`, без попытки переводить подписку в деньги или токены;
- UI не предполагает, что primary всегда означает 5 часов, а secondary всегда неделю, и подписывает окно по фактической длительности.

### PR и commit

- PR: будет создан после публикации ветки;
- commit: будет зафиксирован после применения изменений.

### Незавершённое

- дождаться обязательного CI;
- слить PR;
- выпустить Hermes coder runtime и обновить production bot/orchestration;
- подтвердить реальные значения Plus в Telegram.

### Следующий шаг

После merge выполнить штатный server deploy, затем штатный Hermes coder release/orchestration reconcile и нажать `Обновить балансы`.
''',
)

subprocess.run(
    [
        "python3",
        "scripts/inventory_package_architecture.py",
        "--label",
        "feat-codex-plus-rate-limits",
        "--write",
    ],
    cwd=ROOT,
    check=True,
)
